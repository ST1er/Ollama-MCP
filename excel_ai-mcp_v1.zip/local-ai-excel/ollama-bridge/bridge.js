#!/usr/bin/env node
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { spawn } from 'child_process';
import * as readline from 'readline';

class OllamaMCPBridge {
  constructor(ollamaModel, excelDir) {
    this.ollamaModel = ollamaModel;
    this.excelDir = excelDir;
    this.mcpClient = null;
    this.conversationHistory = [];
  }

  async connectMCPServer() {
    const serverPath = '../mcp-excel-server/index.js';
    
    const transport = new StdioClientTransport({
      command: 'node',
      args: [serverPath, this.excelDir],
    });

    this.mcpClient = new Client({
      name: 'ollama-bridge',
      version: '1.0.0',
    }, {
      capabilities: {},
    });

    await this.mcpClient.connect(transport);
    console.log('✓ Connected to Excel MCP Server\n');
  }

  async getAvailableTools() {
    const { tools } = await this.mcpClient.listTools();
    return tools;
  }

  async callTool(toolName, args) {
    const result = await this.mcpClient.callTool({
      name: toolName,
      arguments: args,
    });
    return result;
  }

  async chat(userMessage) {
    this.conversationHistory.push({
      role: 'user',
      content: userMessage,
    });

    const tools = await this.getAvailableTools();
    
    const toolDescriptions = tools.map(t => 
      `TOOL: ${t.name}\nDESCRIPTION: ${t.description}\nINPUTS: ${JSON.stringify(t.inputSchema.properties, null, 2)}`
    ).join('\n\n');

    const systemPrompt = `You are a helpful and efficient AI assistant with access to Excel file reading tools.

AVAILABLE TOOLS:
${toolDescriptions}

INSTRUCTIONS:
- When you need to use a tool, respond with ONLY a JSON object in this EXACT format:
{"tool":"tool_name","args":{"param":"value"}}

- After using a tool, you'll receive the results. Then provide a helpful response to the user.
- If you don't need a tool, respond naturally to the user.
- Excel files are located in: ${****CHANGE****this.excelDir}
- When referencing files, use just the filename (e.g., "data.xlsx" not full path)

EXAMPLES:
User: "List sheets in data.xlsx"
You: {"tool":"list_sheets","args":{"filepath":"data.xlsx"}}

User: "What's in cell A1 of Sheet1 in report.xlsx?"
You: {"tool":"get_cell_value","args":{"filepath":"report.xlsx","sheet_name":"Sheet1","cell":"A1"}}`;

    let response = await this.callOllama(systemPrompt);
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      attempts++;
      
      const toolCall = this.extractToolCall(response);
      
      if (!toolCall) {
        break;
      }

      console.log(`\n🔧 Using tool: ${toolCall.tool}`);
      console.log(`   Args: ${JSON.stringify(toolCall.args, null, 2)}`);
      
      try {
        const toolResult = await this.callTool(toolCall.tool, toolCall.args);
        
        const resultText = toolResult.content
          .map(c => c.text || '')
          .join('\n');

        console.log(`✓ Tool result received\n`);

        this.conversationHistory.push({
          role: 'assistant',
          content: `[Used tool: ${toolCall.tool}]`,
        });
        
        this.conversationHistory.push({
          role: 'user',
          content: `TOOL RESULT from ${toolCall.tool}:\n${resultText}\n\nNow provide a helpful response to the user based on this result.`,
        });

        response = await this.callOllama(systemPrompt);
      } catch (error) {
        console.error(`✗ Tool error: ${error.message}\n`);
        this.conversationHistory.push({
          role: 'user',
          content: `Tool error: ${error.message}. Please explain this to the user.`,
        });
        response = await this.callOllama(systemPrompt);
        break;
      }
    }

    this.conversationHistory.push({
      role: 'assistant',
      content: response,
    });

    return response;
  }

  extractToolCall(response) {
    try {
      // Look for JSON tool call
      const jsonMatch = response.match(/\{[\s\S]*?"tool"[\s\S]*?\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        if (parsed.tool && parsed.args) {
          return parsed;
        }
      }
    } catch (e) {
      // Not a valid tool call
    }
    return null;
  }

  async callOllama(systemPrompt) {
    return new Promise((resolve, reject) => {
      const messages = [
        { role: 'system', content: systemPrompt },
        ...this.conversationHistory,
      ];

      const payload = JSON.stringify({
        model: this.ollamaModel,
        messages: messages,
        stream: false,
      });

      const ollama = spawn('curl', [
        '-s',
        'http://localhost:11434/api/chat',
        '-H', 'Content-Type: application/json',
        '-d', payload,
      ]);

      let output = '';
      
      ollama.stdout.on('data', (data) => {
        output += data.toString();
      });

      ollama.stderr.on('data', (data) => {
        console.error(`Ollama error: ${data}`);
      });

      ollama.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`Ollama process exited with code ${code}`));
          return;
        }

        try {
          const result = JSON.parse(output);
          resolve(result.message.content);
        } catch (e) {
          reject(new Error(`Failed to parse Ollama response: ${e.message}`));
        }
      });
    });
  }
}

async function main() {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.log('Usage: node bridge.js <ollama-model> <excel-directory>');
    console.log('Example: node bridge.js gemma:2b ~/local-ai-excel/excel-files');
    process.exit(1);
  }

  const [model, excelDir] = args;

  console.log('Starting Ollama-MCP Bridge...');
  console.log(`Model: ${model}`);
  console.log(`Excel Directory: ${excelDir}\n`);

  const bridge = new OllamaMCPBridge(model, excelDir);

  try {
    await bridge.connectMCPServer();
  } catch (error) {
    console.error('Failed to connect to MCP server:', error.message);
    process.exit(1);
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  console.log('Bridge ready! Type your questions (or "exit" to quit):\n');

  const askQuestion = () => {
    rl.question('You: ', async (input) => {
      if (input.toLowerCase() === 'exit') {
        console.log('\nGoodbye!');
        rl.close();
        process.exit(0);
      }

      if (!input.trim()) {
        askQuestion();
        return;
      }

      try {
        const response = await bridge.chat(input);
        console.log(`\nAI: ${response}\n`);
      } catch (error) {
        console.error(`\nError: ${error.message}\n`);
      }

      askQuestion();
    });
  };

  askQuestion();
}

main().catch(console.error);